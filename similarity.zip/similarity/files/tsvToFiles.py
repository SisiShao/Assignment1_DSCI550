import pandas as pd 

tigertsv = pd.read_csv("tiger_final_dataset.tsv", sep = '\t')

i = 1
for index, row in tigertsv.iterrows():
    #line = tigertsv.to_string(header=False)
    outfile = str(i) + ".txt"
    with open (outfile, 'w') as outfile:
        outfile.write(row.to_csv(sep = '\t', index = False))
    i += 1
